-- Vendor table
CREATE TABLE Vendor (
    vendor_id INT PRIMARY KEY AUTO_INCREMENT,
    business_name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    plan_id INT,
    FOREIGN KEY (plan_id) REFERENCES SubscriptionPlan(plan_id)
);

-- Junction table for Product and Category (M:N)
CREATE TABLE ProductCategory (
    product_id INT,
    category_id INT,
    PRIMARY KEY (product_id, category_id),
    FOREIGN KEY (product_id) REFERENCES Product(product_id),
    FOREIGN KEY (category_id) REFERENCES Category(category_id)
);
-- Insert new vendor SmartTech Ltd.
INSERT INTO Vendor (business_name, contact_person, email, phone, address, plan_id)
VALUES (
    'SmartTech Ltd.',
    'Rahim Khan',
    'rahim@smarttech.com',
    '017XXXXXXXX',
    'Dhaka, Bangladesh',
    1
);
-- Insert product Laptop
INSERT INTO Product (vendor_id, product_name, description, price, stock_quantity, status)
VALUES (
    1,
    'Laptop',
    'High performance laptop',
    75000,
    10,
    'active'
);

-- Link product to Electronics category
INSERT INTO ProductCategory (product_id, category_id)
VALUES (1, 1);
-- Update stock quantity of Laptop
UPDATE Product
SET stock_quantity = 15
WHERE product_name = 'Laptop';
-- Delete customer with specific email
DELETE FROM Customer
WHERE email = 'oldcustomer@gmail.com';

-- List vendors with their subscription plan
SELECT v.business_name, s.plan_name, s.price
FROM Vendor v
JOIN SubscriptionPlan s ON v.plan_id = s.plan_id;

-- Products under Electronics category
SELECT p.product_name, p.price, p.stock_quantity
FROM Product p
JOIN ProductCategory pc ON p.product_id = pc.product_id
JOIN Category c ON pc.category_id = c.category_id
WHERE c.category_name = 'Electronics';

-- Orders placed by Karim Uddin
SELECT o.order_id, o.order_date, o.total_amount, o.order_status
FROM `Order` o
JOIN Customer c ON o.customer_id = c.customer_id
WHERE c.name = 'Karim Uddin';

-- Payment details for order 1
SELECT payment_method, amount, payment_status
FROM Payment
WHERE order_id = 1;

-- Top 5 best-selling products by quantity sold
SELECT p.product_name, SUM(oi.quantity) AS total_sold
FROM OrderItem oi
JOIN Product p ON oi.product_id = p.product_id
GROUP BY p.product_name
ORDER BY total_sold DESC
LIMIT 5;
